export const patternStyles = {
    dots: "dots",
    squares: "squares",
    rounded: "rounded",
    // Add other patterns as needed
  };