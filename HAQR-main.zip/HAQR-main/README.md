this is a website where you can generate dynamic qrcode with live analytics and many more modificatoins on your qrcode
